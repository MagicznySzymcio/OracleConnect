create PROCEDURE TEST
AS
  c1 SYS_REFCURSOR;  
BEGIN

  OPEN c1 FOR 
    SELECT * FROM  lotniska;
  dbms_sql.return_result(c1);

END TEST;
/

